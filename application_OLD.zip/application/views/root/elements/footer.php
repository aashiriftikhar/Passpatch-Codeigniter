
<strong>Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo base_url('root/Home'); ?>"><?php echo $siteSettings['name']; ?></a>.</strong> All rights reserved.