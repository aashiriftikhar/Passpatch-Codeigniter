<div class="login-box" style="margin: 5% auto;">
  <div class="login-logo">
    <h2 class="tagline">Detect a Fever the Moment it Starts.</h2>
  </div>
  <div class="login-box-body">
    <img src="<?php echo base_url()?>assets/watch.png" style="width: 50%;
      margin: auto;
      display: block;">
    <div class="row">
      <div class="col-xs-12">
        <a href="<?php echo base_url('Auth/Login')?>" class="login-btn btn-block btn-flat">Login</a>
      </div>
    </div>
    <a href="#"><img src="<?php echo base_url()?>assets/logo.png" style="width: 35%;margin: auto;display: block;margin-top: 20px;"></a>
    <h4 style="color: #fff;text-align: center;margin-top: 10px;font-size: 15px;font-family: raleway;">Promoting a Healthy Environment for All</h4>
    <p style="color: #fff;text-align: center;margin-top: 35px;font-weight: 500;font-size: 12px;font-family: raleway;">PASSPATCH LLC ALL RIGHTS RESERVED 2020</p>
    <!-- </form> -->
    <!-- <a href="#">I forgot my password</a> -->
  </div>
</div>

