
<strong>Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo base_url('admin/administrative/dashboard'); ?>"><?php echo $siteSettings['name']; ?></a>.</strong> All rights reserved.