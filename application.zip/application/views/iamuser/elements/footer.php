
<strong>Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo base_url('iamuser/Home'); ?>"><?php echo $siteSettings['name']; ?></a>.</strong> All rights reserved.