<!DOCTYPE html>
<html>
<head>
	<!-- render head view -->
	<?php echo $head; ?>
</head>
<body class="hold-transition login-page">
	<!-- render main page content view -->
	<?php echo $maincontent; ?>
</body>
</html>